#  Yusuf Çiftci & Önder Can Köse
## Hocam please select dark mode for better visuals.
## If there is problem with api key you can get it from https://spoonacular.com/food-api/ 
