//
//  userData.swift
//  CTIS480_Project
//
//  Created by Yusuf Çiftci on 27.12.2022.
//

import Foundation

public struct userData {
    var gender = " "
    var age = 0
    var weight = 0
    var height = 0
    var name = " "
    var bmr = 0.0
    var count = 0

}
public var localUser = userData()
