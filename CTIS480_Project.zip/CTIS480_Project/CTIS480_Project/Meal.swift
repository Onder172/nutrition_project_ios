//
//  Meal.swift
//  CTIS480_Project
//
//  Created by Yusuf Çiftci on 29.12.2022.
//

import Foundation

public struct MealS {
    var day: String
   var id: Int
   var title: String
   var image: String
   var imageType: String
}
