//
//  User+CoreDataClass.swift
//  CTIS480_Project
//
//  Created by Yusuf Çiftci on 27.12.2022.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
