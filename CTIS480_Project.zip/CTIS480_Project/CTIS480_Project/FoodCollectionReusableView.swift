//
//  FoodCollectionReusableView.swift
//  CTIS480_Project
//
//  Created by Yusuf Çiftci on 1.01.2023.
//

import UIKit

class FoodCollectionReusableView: UICollectionReusableView {
        
    
    @IBOutlet weak var mHeaderLabel: UILabel!
}
